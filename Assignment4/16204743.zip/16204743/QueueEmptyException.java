
public class QueueEmptyException extends RuntimeException {
	
}
