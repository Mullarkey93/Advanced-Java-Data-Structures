s
public class FullQueueException extends RuntimeException {

}
